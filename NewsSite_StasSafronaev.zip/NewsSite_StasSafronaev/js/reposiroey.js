var Article1 = { id: "001", headline: "Arsene Wenger charged by FA after Arsenal draw with West Brom", main: "full article" }
var Article2 = { id: "002", headline: "Mark Hughes' future as Stoke manager under review", main: "full article" }
var Article3 = { id: "003", headline: "Antonio Conte not expecting David Luiz to leave Chelsea in January", main: "full article" }

var Articles = [Article1, Article2, Article3];

function AddPerson(article){
    if(CheckIfNewPersinIsValid(article))
    {
        Articles.push(article);
    }    
}

function CheckIfNewPersinIsValid(article)
{
    if(GetPersonIndex(article.id) > -1){
        return false;
    }
}

function GetPerson(articleId){
    var index = GetPersonIndex(articleId);
    if(index > -1){
            return Articles[index];
    }
    return null;
}

function GetPersonIndex(articleId){
    for(i = 0; i < Articles.length; i++){
        if(Articles[i].id == articleId){
            return i;
        }
    }
    return -1;
}

function GetAll(){
    return Articles;
} 

function Delete(articleId){
    Articles.splice(GetPersonIndex(articleId) ,1);
}

function Update(article){
    var index = GetPersonIndex(article.id);
    if(index > -1){
        Articles[index] = article;
    }
}

function Test(){
    return "in test method";
}
