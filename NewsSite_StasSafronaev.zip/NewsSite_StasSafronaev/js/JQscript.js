$(document).ready(function () {
    $("#buttonNum0").hover(function () {
        $("#details").text($.param(allArticles[0]));


    });
    $("#buttonNum1").hover(function () {
        $("#details").text($.param(allArticles[1]));


    });

    $("#buttonNum2").hover(function () {
        $("#details").text($.param(allArticles[2]));


    });


});
